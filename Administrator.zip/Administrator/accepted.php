<!DOCTYPE html>
	<head>
		<title>Oops</title>
		<link rel="stylesheet" type="text/css" href="resources/css/global.css">
	</head>
	<body>
		<div class = "bgerror">
			<div class ="error">
				<h1>Already Accepted</h1>
				<button><a href = 'admin.php'>Okay</a></button>
			</div>
		</div>
	</body>
</html>