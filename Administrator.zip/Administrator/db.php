<?php
	$db = mysqli_connect('localhost', 'root', '', 'dbase');