<!DOCTYPE html>
	<head>
		<title>Oops</title>
		<link rel="stylesheet" type="text/css" href="resources/css/global.css">
	</head>
	<body>
		<div class = "bgerror">
			<div class ="error">
				<h1>Your session has expired. Please re-login</h1>
				<button><a href = 'index.php'>Okay</a></button>
			</div>
		</div>
	</body>
</html>