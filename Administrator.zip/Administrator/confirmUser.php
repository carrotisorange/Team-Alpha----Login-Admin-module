<?php
	require 'db.php';
	session_start();
	$count = $_SESSION['count'];
	for($c = 1; $c < $count; $c++) {
		$id = $_SESSION['person'.$c];
		$accept = "UPDATE users SET status='customer' WHERE userid='$id'";
		$reject = "DELETE FROM users WHERE userid='$id'";
		$checker = "SELECT * FROM users WHERE userid = '$id'";
		$result = mysqli_query($db,$checker);
		$row = mysqli_fetch_array($result);
		if(isset($_POST['Accept'.$c])) {
			if(mysqli_num_rows($result) == 0) {
				header("Location: rejected.php");
			}
			else if($row['status'] == 'customer') {
				header("Location: accepted.php");
			}
			else if(mysqli_query($db, $accept)){
				$msg = "Account has been accepted.";
				echo "<script type='text/javascript'>alert('$msg');</script>";
				header("Location: admin.php");
			} else {
				echo "Error updating record.";
			}
			break;
		}
		else if(isset($_POST['Reject'.$c])) {
			if(mysqli_num_rows($result) == 0) {
				header("Location: rejected.php");
			}
			else if($row['status'] == 'customer') {
				header("Location: accepted.php");
			}
			else if(mysqli_query($db, $reject)){
				$msg = "Account has been removed.";
				echo "<script type='text/javascript'>alert('$msg');</script>";
				header("Location: admin.php");
			} else {
				echo "Error updating record.";
			}
			break;
		}
	}
?>