<?php
	require 'db.php';
	session_start();
	$count = $_SESSION['counts'];
	$date = date("Y-m-d");
	for($c = 1; $c < $count; $c++) {
		$id = $_SESSION['product'.$c];
		$post = "UPDATE products SET isApproved='Y', dateApproved='$date' WHERE prodid='$id'";
		$reject = "DELETE FROM products WHERE prodid='$id'";
		$checker = "SELECT * FROM products WHERE prodid = '$id'";
		$result = mysqli_query($db,$checker);
		$row = mysqli_fetch_array($result);
		if(isset($_POST['Post'.$c])) {
			if(mysqli_num_rows($result) == 0) {
				header("Location: rejected.php");
			}
			else if($row['isApproved'] == 'Y') {
				header("Location: accepted.php");
			}
			else if(mysqli_query($db, $post)){
				$msg = "Product has been approved.";
				echo "<script type='text/javascript'>alert('$msg');</script>";
				header("Location: admin.php");
			} else {
				echo "Error updating record.";
			}
			break;
		}
		else if(isset($_POST['Reject'.$c])){
			if(mysqli_num_rows($result) == 0) {
				header("Location: rejected.php");
			}
			else if($row['isApproved'] == 'Y') {
				header("Location: accepted.php");
			}
			else if(mysqli_query($db, $reject)){
				$msg = "Product has been removed.";
				echo "<script type='text/javascript'>alert('$msg');</script>";
				header("Location:  admin.php");
			} else {
				echo "Error updating record.";
			}
			break;
		}
	}
?>