var x = document.getElementById("editBut");
console.log(x);