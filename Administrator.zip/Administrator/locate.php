<?php
	require 'db.php';
	session_start();

	$_SESSION['email'] = $_POST['email'];

	$email = $_SESSION['email'];
	$password = $_POST['password'];
	$query = mysqli_query($db, "SELECT * FROM users WHERE email = '$email'");

	if(isset($_POST['Give'])) {
		if(!$row = mysqli_fetch_array($query)) {
			header('Location: errorreg.php');
		}
		else if ($row['password'] != md5($password)) {
			header('Location: errorpass.php');
		}
		else if($row['status'] == 'pending') {
			header('Location: errorpen.php');

		}
		else if ($row['status'] == admin) {
			header('Location: admin.php');
		}
		else {
			header('Location: givemain.html');
		}
	}
	if(isset($_POST['Take'])) {
		if(!$row = mysqli_fetch_array($query)) {
			header('Location: errorreg.php');
		}
		else if ($row['password'] != md5($password)) {
			header('Location: errorpass.php');
		}
		else if($row['status'] == 'pending') {
			header('Location: errorpen.php');

		}
		else if ($row['status'] == admin) {
			header('Location: admin.php');
		}
		else {
			header('Location: takemain.html');
		}	
	}
	